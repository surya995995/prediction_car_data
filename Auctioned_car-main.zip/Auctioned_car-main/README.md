# Auctioned_car

### dataset link: https://www.kaggle.com/competitions/DontGetKicked/data
